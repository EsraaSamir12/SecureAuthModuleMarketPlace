﻿namespace IA_marketPlace.Data
{
    public class ProductPostDto
    {
    }
}
