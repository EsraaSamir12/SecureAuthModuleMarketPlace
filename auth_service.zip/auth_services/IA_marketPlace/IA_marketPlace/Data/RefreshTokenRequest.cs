﻿namespace IA_marketPlace.Data
{
    public class RefreshTokenRequest
    {
        public string Token { get; set; }
    }
}
